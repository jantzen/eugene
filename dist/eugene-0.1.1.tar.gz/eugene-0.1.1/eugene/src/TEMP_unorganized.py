import numpy as np


#Classes:
#  Range


#Functions:
# 



##################################################################
##################################################################
#Classes:

class Range( object ):
    """Specifies both the start and the end of a range of numbers
    """
    def __init__(self, start, end):
        self._start = start
        self._end = end
        



