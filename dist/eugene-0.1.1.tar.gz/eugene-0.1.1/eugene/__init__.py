from .src import categorize
from .src import compare
from .src import interface
from .src.connect import sensors
from .src.connect import actuators

# import .tests
# import .scripts_demos

